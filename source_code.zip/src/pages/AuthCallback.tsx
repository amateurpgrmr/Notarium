// src/pages/AuthCallback.tsx
import { useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';

export default function AuthCallback() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();

  useEffect(() => {
    const code = searchParams.get('code');
    if (code) {
      // Call backend to exchange code for token
      fetch('/api/auth/callback?code=' + code)
        .then(res => {
          if (!res.ok) throw new Error('Auth failed');
          return res.json();
        })
        .then(data => {
          localStorage.setItem('token', data.token);
          navigate('/');
        })
        .catch(err => {
          console.error('Auth failed', err);
          navigate('/login?error=1');
        });
    } else {
      navigate('/login?error=1');
    }
  }, [searchParams, navigate]);

  return <div>Loading...</div>;
}