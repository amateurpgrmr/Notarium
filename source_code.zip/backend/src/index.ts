import { Hono } from 'hono'
const app = new Hono()

app.get('/', (c) => c.text('OK'))

app.post('/api/gemini/chat', async (c) => {
  let body = {}
  try { body = await c.req.json() } catch (e) { return c.json({ error: 'Invalid JSON' }, 400) }

  const messages = body.messages || []
  if (messages.length === 0) return c.json({ error: 'No message' }, 400)

  const userMessage = messages.find(m => m.role === 'user')?.content || messages[0]?.content
  if (!userMessage) return c.json({ error: 'No user message' }, 400)

  const GEMINI_API_KEY = c.env.GEMINI_API_KEY
  if (!GEMINI_API_KEY) return c.json({ response: '[MOCK] Key missing' })

  const res = await fetch(
    `https://generativelanguage.googleapis.com/v1/models/gemini-1.5-flash:generateContent?key=${GEMINI_API_KEY}`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{ role: 'user', parts: [{ text: userMessage }] }]
      })
    }
  )

  if (!res.ok) {
    const err = await res.text()
    console.error('Gemini error:', err)
    return c.json({ error: 'AI service unavailable' }, 500)
  }

  const data = await res.json()
  const reply = data.candidates?.[0]?.content?.parts?.[0]?.text || 'No reply'
  return c.json({ response: reply })
})

app.post('/api/gemini/ocr', async (c) => c.json({ text: '[MOCK OCR]' }))

export default app
