var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __publicField = (obj, key, value) => {
  __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
  return value;
};

// node_modules/unenv/dist/runtime/_internal/utils.mjs
function createNotImplementedError(name) {
  return new Error(`[unenv] ${name} is not implemented yet!`);
}
__name(createNotImplementedError, "createNotImplementedError");
function notImplemented(name) {
  const fn = /* @__PURE__ */ __name(() => {
    throw createNotImplementedError(name);
  }, "fn");
  return Object.assign(fn, { __unenv__: true });
}
__name(notImplemented, "notImplemented");
function notImplementedClass(name) {
  return class {
    __unenv__ = true;
    constructor() {
      throw new Error(`[unenv] ${name} is not implemented yet!`);
    }
  };
}
__name(notImplementedClass, "notImplementedClass");

// node_modules/unenv/dist/runtime/node/internal/perf_hooks/performance.mjs
var _timeOrigin = globalThis.performance?.timeOrigin ?? Date.now();
var _performanceNow = globalThis.performance?.now ? globalThis.performance.now.bind(globalThis.performance) : () => Date.now() - _timeOrigin;
var nodeTiming = {
  name: "node",
  entryType: "node",
  startTime: 0,
  duration: 0,
  nodeStart: 0,
  v8Start: 0,
  bootstrapComplete: 0,
  environment: 0,
  loopStart: 0,
  loopExit: 0,
  idleTime: 0,
  uvMetricsInfo: {
    loopCount: 0,
    events: 0,
    eventsWaiting: 0
  },
  detail: void 0,
  toJSON() {
    return this;
  }
};
var PerformanceEntry = class {
  __unenv__ = true;
  detail;
  entryType = "event";
  name;
  startTime;
  constructor(name, options) {
    this.name = name;
    this.startTime = options?.startTime || _performanceNow();
    this.detail = options?.detail;
  }
  get duration() {
    return _performanceNow() - this.startTime;
  }
  toJSON() {
    return {
      name: this.name,
      entryType: this.entryType,
      startTime: this.startTime,
      duration: this.duration,
      detail: this.detail
    };
  }
};
__name(PerformanceEntry, "PerformanceEntry");
var PerformanceMark = /* @__PURE__ */ __name(class PerformanceMark2 extends PerformanceEntry {
  entryType = "mark";
  constructor() {
    super(...arguments);
  }
  get duration() {
    return 0;
  }
}, "PerformanceMark");
var PerformanceMeasure = class extends PerformanceEntry {
  entryType = "measure";
};
__name(PerformanceMeasure, "PerformanceMeasure");
var PerformanceResourceTiming = class extends PerformanceEntry {
  entryType = "resource";
  serverTiming = [];
  connectEnd = 0;
  connectStart = 0;
  decodedBodySize = 0;
  domainLookupEnd = 0;
  domainLookupStart = 0;
  encodedBodySize = 0;
  fetchStart = 0;
  initiatorType = "";
  name = "";
  nextHopProtocol = "";
  redirectEnd = 0;
  redirectStart = 0;
  requestStart = 0;
  responseEnd = 0;
  responseStart = 0;
  secureConnectionStart = 0;
  startTime = 0;
  transferSize = 0;
  workerStart = 0;
  responseStatus = 0;
};
__name(PerformanceResourceTiming, "PerformanceResourceTiming");
var PerformanceObserverEntryList = class {
  __unenv__ = true;
  getEntries() {
    return [];
  }
  getEntriesByName(_name, _type) {
    return [];
  }
  getEntriesByType(type) {
    return [];
  }
};
__name(PerformanceObserverEntryList, "PerformanceObserverEntryList");
var Performance = class {
  __unenv__ = true;
  timeOrigin = _timeOrigin;
  eventCounts = /* @__PURE__ */ new Map();
  _entries = [];
  _resourceTimingBufferSize = 0;
  navigation = void 0;
  timing = void 0;
  timerify(_fn, _options) {
    throw createNotImplementedError("Performance.timerify");
  }
  get nodeTiming() {
    return nodeTiming;
  }
  eventLoopUtilization() {
    return {};
  }
  markResourceTiming() {
    return new PerformanceResourceTiming("");
  }
  onresourcetimingbufferfull = null;
  now() {
    if (this.timeOrigin === _timeOrigin) {
      return _performanceNow();
    }
    return Date.now() - this.timeOrigin;
  }
  clearMarks(markName) {
    this._entries = markName ? this._entries.filter((e) => e.name !== markName) : this._entries.filter((e) => e.entryType !== "mark");
  }
  clearMeasures(measureName) {
    this._entries = measureName ? this._entries.filter((e) => e.name !== measureName) : this._entries.filter((e) => e.entryType !== "measure");
  }
  clearResourceTimings() {
    this._entries = this._entries.filter((e) => e.entryType !== "resource" || e.entryType !== "navigation");
  }
  getEntries() {
    return this._entries;
  }
  getEntriesByName(name, type) {
    return this._entries.filter((e) => e.name === name && (!type || e.entryType === type));
  }
  getEntriesByType(type) {
    return this._entries.filter((e) => e.entryType === type);
  }
  mark(name, options) {
    const entry = new PerformanceMark(name, options);
    this._entries.push(entry);
    return entry;
  }
  measure(measureName, startOrMeasureOptions, endMark) {
    let start;
    let end;
    if (typeof startOrMeasureOptions === "string") {
      start = this.getEntriesByName(startOrMeasureOptions, "mark")[0]?.startTime;
      end = this.getEntriesByName(endMark, "mark")[0]?.startTime;
    } else {
      start = Number.parseFloat(startOrMeasureOptions?.start) || this.now();
      end = Number.parseFloat(startOrMeasureOptions?.end) || this.now();
    }
    const entry = new PerformanceMeasure(measureName, {
      startTime: start,
      detail: {
        start,
        end
      }
    });
    this._entries.push(entry);
    return entry;
  }
  setResourceTimingBufferSize(maxSize) {
    this._resourceTimingBufferSize = maxSize;
  }
  addEventListener(type, listener, options) {
    throw createNotImplementedError("Performance.addEventListener");
  }
  removeEventListener(type, listener, options) {
    throw createNotImplementedError("Performance.removeEventListener");
  }
  dispatchEvent(event) {
    throw createNotImplementedError("Performance.dispatchEvent");
  }
  toJSON() {
    return this;
  }
};
__name(Performance, "Performance");
var PerformanceObserver = class {
  __unenv__ = true;
  _callback = null;
  constructor(callback) {
    this._callback = callback;
  }
  takeRecords() {
    return [];
  }
  disconnect() {
    throw createNotImplementedError("PerformanceObserver.disconnect");
  }
  observe(options) {
    throw createNotImplementedError("PerformanceObserver.observe");
  }
  bind(fn) {
    return fn;
  }
  runInAsyncScope(fn, thisArg, ...args) {
    return fn.call(thisArg, ...args);
  }
  asyncId() {
    return 0;
  }
  triggerAsyncId() {
    return 0;
  }
  emitDestroy() {
    return this;
  }
};
__name(PerformanceObserver, "PerformanceObserver");
__publicField(PerformanceObserver, "supportedEntryTypes", []);
var performance = globalThis.performance && "addEventListener" in globalThis.performance ? globalThis.performance : new Performance();

// node_modules/@cloudflare/unenv-preset/dist/runtime/polyfill/performance.mjs
globalThis.performance = performance;
globalThis.Performance = Performance;
globalThis.PerformanceEntry = PerformanceEntry;
globalThis.PerformanceMark = PerformanceMark;
globalThis.PerformanceMeasure = PerformanceMeasure;
globalThis.PerformanceObserver = PerformanceObserver;
globalThis.PerformanceObserverEntryList = PerformanceObserverEntryList;
globalThis.PerformanceResourceTiming = PerformanceResourceTiming;

// node_modules/unenv/dist/runtime/node/console.mjs
import { Writable } from "node:stream";

// node_modules/unenv/dist/runtime/mock/noop.mjs
var noop_default = Object.assign(() => {
}, { __unenv__: true });

// node_modules/unenv/dist/runtime/node/console.mjs
var _console = globalThis.console;
var _ignoreErrors = true;
var _stderr = new Writable();
var _stdout = new Writable();
var log = _console?.log ?? noop_default;
var info = _console?.info ?? log;
var trace = _console?.trace ?? info;
var debug = _console?.debug ?? log;
var table = _console?.table ?? log;
var error = _console?.error ?? log;
var warn = _console?.warn ?? error;
var createTask = _console?.createTask ?? /* @__PURE__ */ notImplemented("console.createTask");
var clear = _console?.clear ?? noop_default;
var count = _console?.count ?? noop_default;
var countReset = _console?.countReset ?? noop_default;
var dir = _console?.dir ?? noop_default;
var dirxml = _console?.dirxml ?? noop_default;
var group = _console?.group ?? noop_default;
var groupEnd = _console?.groupEnd ?? noop_default;
var groupCollapsed = _console?.groupCollapsed ?? noop_default;
var profile = _console?.profile ?? noop_default;
var profileEnd = _console?.profileEnd ?? noop_default;
var time = _console?.time ?? noop_default;
var timeEnd = _console?.timeEnd ?? noop_default;
var timeLog = _console?.timeLog ?? noop_default;
var timeStamp = _console?.timeStamp ?? noop_default;
var Console = _console?.Console ?? /* @__PURE__ */ notImplementedClass("console.Console");
var _times = /* @__PURE__ */ new Map();
var _stdoutErrorHandler = noop_default;
var _stderrErrorHandler = noop_default;

// node_modules/@cloudflare/unenv-preset/dist/runtime/node/console.mjs
var workerdConsole = globalThis["console"];
var {
  assert,
  clear: clear2,
  // @ts-expect-error undocumented public API
  context,
  count: count2,
  countReset: countReset2,
  // @ts-expect-error undocumented public API
  createTask: createTask2,
  debug: debug2,
  dir: dir2,
  dirxml: dirxml2,
  error: error2,
  group: group2,
  groupCollapsed: groupCollapsed2,
  groupEnd: groupEnd2,
  info: info2,
  log: log2,
  profile: profile2,
  profileEnd: profileEnd2,
  table: table2,
  time: time2,
  timeEnd: timeEnd2,
  timeLog: timeLog2,
  timeStamp: timeStamp2,
  trace: trace2,
  warn: warn2
} = workerdConsole;
Object.assign(workerdConsole, {
  Console,
  _ignoreErrors,
  _stderr,
  _stderrErrorHandler,
  _stdout,
  _stdoutErrorHandler,
  _times
});
var console_default = workerdConsole;

// node_modules/wrangler/_virtual_unenv_global_polyfill-@cloudflare-unenv-preset-node-console
globalThis.console = console_default;

// node_modules/unenv/dist/runtime/node/internal/process/hrtime.mjs
var hrtime = /* @__PURE__ */ Object.assign(/* @__PURE__ */ __name(function hrtime2(startTime) {
  const now = Date.now();
  const seconds = Math.trunc(now / 1e3);
  const nanos = now % 1e3 * 1e6;
  if (startTime) {
    let diffSeconds = seconds - startTime[0];
    let diffNanos = nanos - startTime[0];
    if (diffNanos < 0) {
      diffSeconds = diffSeconds - 1;
      diffNanos = 1e9 + diffNanos;
    }
    return [diffSeconds, diffNanos];
  }
  return [seconds, nanos];
}, "hrtime"), { bigint: /* @__PURE__ */ __name(function bigint() {
  return BigInt(Date.now() * 1e6);
}, "bigint") });

// node_modules/unenv/dist/runtime/node/internal/process/process.mjs
import { EventEmitter } from "node:events";

// node_modules/unenv/dist/runtime/node/internal/tty/read-stream.mjs
import { Socket } from "node:net";
var ReadStream = class extends Socket {
  fd;
  constructor(fd) {
    super();
    this.fd = fd;
  }
  isRaw = false;
  setRawMode(mode) {
    this.isRaw = mode;
    return this;
  }
  isTTY = false;
};
__name(ReadStream, "ReadStream");

// node_modules/unenv/dist/runtime/node/internal/tty/write-stream.mjs
import { Socket as Socket2 } from "node:net";
var WriteStream = class extends Socket2 {
  fd;
  constructor(fd) {
    super();
    this.fd = fd;
  }
  clearLine(dir3, callback) {
    callback && callback();
    return false;
  }
  clearScreenDown(callback) {
    callback && callback();
    return false;
  }
  cursorTo(x, y, callback) {
    callback && typeof callback === "function" && callback();
    return false;
  }
  moveCursor(dx, dy, callback) {
    callback && callback();
    return false;
  }
  getColorDepth(env2) {
    return 1;
  }
  hasColors(count3, env2) {
    return false;
  }
  getWindowSize() {
    return [this.columns, this.rows];
  }
  columns = 80;
  rows = 24;
  isTTY = false;
};
__name(WriteStream, "WriteStream");

// node_modules/unenv/dist/runtime/node/internal/process/process.mjs
var Process = class extends EventEmitter {
  env;
  hrtime;
  nextTick;
  constructor(impl) {
    super();
    this.env = impl.env;
    this.hrtime = impl.hrtime;
    this.nextTick = impl.nextTick;
    for (const prop of [...Object.getOwnPropertyNames(Process.prototype), ...Object.getOwnPropertyNames(EventEmitter.prototype)]) {
      const value = this[prop];
      if (typeof value === "function") {
        this[prop] = value.bind(this);
      }
    }
  }
  emitWarning(warning, type, code) {
    console.warn(`${code ? `[${code}] ` : ""}${type ? `${type}: ` : ""}${warning}`);
  }
  emit(...args) {
    return super.emit(...args);
  }
  listeners(eventName) {
    return super.listeners(eventName);
  }
  #stdin;
  #stdout;
  #stderr;
  get stdin() {
    return this.#stdin ??= new ReadStream(0);
  }
  get stdout() {
    return this.#stdout ??= new WriteStream(1);
  }
  get stderr() {
    return this.#stderr ??= new WriteStream(2);
  }
  #cwd = "/";
  chdir(cwd2) {
    this.#cwd = cwd2;
  }
  cwd() {
    return this.#cwd;
  }
  arch = "";
  platform = "";
  argv = [];
  argv0 = "";
  execArgv = [];
  execPath = "";
  title = "";
  pid = 200;
  ppid = 100;
  get version() {
    return "";
  }
  get versions() {
    return {};
  }
  get allowedNodeEnvironmentFlags() {
    return /* @__PURE__ */ new Set();
  }
  get sourceMapsEnabled() {
    return false;
  }
  get debugPort() {
    return 0;
  }
  get throwDeprecation() {
    return false;
  }
  get traceDeprecation() {
    return false;
  }
  get features() {
    return {};
  }
  get release() {
    return {};
  }
  get connected() {
    return false;
  }
  get config() {
    return {};
  }
  get moduleLoadList() {
    return [];
  }
  constrainedMemory() {
    return 0;
  }
  availableMemory() {
    return 0;
  }
  uptime() {
    return 0;
  }
  resourceUsage() {
    return {};
  }
  ref() {
  }
  unref() {
  }
  umask() {
    throw createNotImplementedError("process.umask");
  }
  getBuiltinModule() {
    return void 0;
  }
  getActiveResourcesInfo() {
    throw createNotImplementedError("process.getActiveResourcesInfo");
  }
  exit() {
    throw createNotImplementedError("process.exit");
  }
  reallyExit() {
    throw createNotImplementedError("process.reallyExit");
  }
  kill() {
    throw createNotImplementedError("process.kill");
  }
  abort() {
    throw createNotImplementedError("process.abort");
  }
  dlopen() {
    throw createNotImplementedError("process.dlopen");
  }
  setSourceMapsEnabled() {
    throw createNotImplementedError("process.setSourceMapsEnabled");
  }
  loadEnvFile() {
    throw createNotImplementedError("process.loadEnvFile");
  }
  disconnect() {
    throw createNotImplementedError("process.disconnect");
  }
  cpuUsage() {
    throw createNotImplementedError("process.cpuUsage");
  }
  setUncaughtExceptionCaptureCallback() {
    throw createNotImplementedError("process.setUncaughtExceptionCaptureCallback");
  }
  hasUncaughtExceptionCaptureCallback() {
    throw createNotImplementedError("process.hasUncaughtExceptionCaptureCallback");
  }
  initgroups() {
    throw createNotImplementedError("process.initgroups");
  }
  openStdin() {
    throw createNotImplementedError("process.openStdin");
  }
  assert() {
    throw createNotImplementedError("process.assert");
  }
  binding() {
    throw createNotImplementedError("process.binding");
  }
  permission = { has: /* @__PURE__ */ notImplemented("process.permission.has") };
  report = {
    directory: "",
    filename: "",
    signal: "SIGUSR2",
    compact: false,
    reportOnFatalError: false,
    reportOnSignal: false,
    reportOnUncaughtException: false,
    getReport: /* @__PURE__ */ notImplemented("process.report.getReport"),
    writeReport: /* @__PURE__ */ notImplemented("process.report.writeReport")
  };
  finalization = {
    register: /* @__PURE__ */ notImplemented("process.finalization.register"),
    unregister: /* @__PURE__ */ notImplemented("process.finalization.unregister"),
    registerBeforeExit: /* @__PURE__ */ notImplemented("process.finalization.registerBeforeExit")
  };
  memoryUsage = Object.assign(() => ({
    arrayBuffers: 0,
    rss: 0,
    external: 0,
    heapTotal: 0,
    heapUsed: 0
  }), { rss: () => 0 });
  mainModule = void 0;
  domain = void 0;
  send = void 0;
  exitCode = void 0;
  channel = void 0;
  getegid = void 0;
  geteuid = void 0;
  getgid = void 0;
  getgroups = void 0;
  getuid = void 0;
  setegid = void 0;
  seteuid = void 0;
  setgid = void 0;
  setgroups = void 0;
  setuid = void 0;
  _events = void 0;
  _eventsCount = void 0;
  _exiting = void 0;
  _maxListeners = void 0;
  _debugEnd = void 0;
  _debugProcess = void 0;
  _fatalException = void 0;
  _getActiveHandles = void 0;
  _getActiveRequests = void 0;
  _kill = void 0;
  _preload_modules = void 0;
  _rawDebug = void 0;
  _startProfilerIdleNotifier = void 0;
  _stopProfilerIdleNotifier = void 0;
  _tickCallback = void 0;
  _disconnect = void 0;
  _handleQueue = void 0;
  _pendingMessage = void 0;
  _channel = void 0;
  _send = void 0;
  _linkedBinding = void 0;
};
__name(Process, "Process");

// node_modules/@cloudflare/unenv-preset/dist/runtime/node/process.mjs
var globalProcess = globalThis["process"];
var getBuiltinModule = globalProcess.getBuiltinModule;
var { exit, platform, nextTick } = getBuiltinModule(
  "node:process"
);
var unenvProcess = new Process({
  env: globalProcess.env,
  hrtime,
  nextTick
});
var {
  abort,
  addListener,
  allowedNodeEnvironmentFlags,
  hasUncaughtExceptionCaptureCallback,
  setUncaughtExceptionCaptureCallback,
  loadEnvFile,
  sourceMapsEnabled,
  arch,
  argv,
  argv0,
  chdir,
  config,
  connected,
  constrainedMemory,
  availableMemory,
  cpuUsage,
  cwd,
  debugPort,
  dlopen,
  disconnect,
  emit,
  emitWarning,
  env,
  eventNames,
  execArgv,
  execPath,
  finalization,
  features,
  getActiveResourcesInfo,
  getMaxListeners,
  hrtime: hrtime3,
  kill,
  listeners,
  listenerCount,
  memoryUsage,
  on,
  off,
  once,
  pid,
  ppid,
  prependListener,
  prependOnceListener,
  rawListeners,
  release,
  removeAllListeners,
  removeListener,
  report,
  resourceUsage,
  setMaxListeners,
  setSourceMapsEnabled,
  stderr,
  stdin,
  stdout,
  title,
  throwDeprecation,
  traceDeprecation,
  umask,
  uptime,
  version,
  versions,
  domain,
  initgroups,
  moduleLoadList,
  reallyExit,
  openStdin,
  assert: assert2,
  binding,
  send,
  exitCode,
  channel,
  getegid,
  geteuid,
  getgid,
  getgroups,
  getuid,
  setegid,
  seteuid,
  setgid,
  setgroups,
  setuid,
  permission,
  mainModule,
  _events,
  _eventsCount,
  _exiting,
  _maxListeners,
  _debugEnd,
  _debugProcess,
  _fatalException,
  _getActiveHandles,
  _getActiveRequests,
  _kill,
  _preload_modules,
  _rawDebug,
  _startProfilerIdleNotifier,
  _stopProfilerIdleNotifier,
  _tickCallback,
  _disconnect,
  _handleQueue,
  _pendingMessage,
  _channel,
  _send,
  _linkedBinding
} = unenvProcess;
var _process = {
  abort,
  addListener,
  allowedNodeEnvironmentFlags,
  hasUncaughtExceptionCaptureCallback,
  setUncaughtExceptionCaptureCallback,
  loadEnvFile,
  sourceMapsEnabled,
  arch,
  argv,
  argv0,
  chdir,
  config,
  connected,
  constrainedMemory,
  availableMemory,
  cpuUsage,
  cwd,
  debugPort,
  dlopen,
  disconnect,
  emit,
  emitWarning,
  env,
  eventNames,
  execArgv,
  execPath,
  exit,
  finalization,
  features,
  getBuiltinModule,
  getActiveResourcesInfo,
  getMaxListeners,
  hrtime: hrtime3,
  kill,
  listeners,
  listenerCount,
  memoryUsage,
  nextTick,
  on,
  off,
  once,
  pid,
  platform,
  ppid,
  prependListener,
  prependOnceListener,
  rawListeners,
  release,
  removeAllListeners,
  removeListener,
  report,
  resourceUsage,
  setMaxListeners,
  setSourceMapsEnabled,
  stderr,
  stdin,
  stdout,
  title,
  throwDeprecation,
  traceDeprecation,
  umask,
  uptime,
  version,
  versions,
  // @ts-expect-error old API
  domain,
  initgroups,
  moduleLoadList,
  reallyExit,
  openStdin,
  assert: assert2,
  binding,
  send,
  exitCode,
  channel,
  getegid,
  geteuid,
  getgid,
  getgroups,
  getuid,
  setegid,
  seteuid,
  setgid,
  setgroups,
  setuid,
  permission,
  mainModule,
  _events,
  _eventsCount,
  _exiting,
  _maxListeners,
  _debugEnd,
  _debugProcess,
  _fatalException,
  _getActiveHandles,
  _getActiveRequests,
  _kill,
  _preload_modules,
  _rawDebug,
  _startProfilerIdleNotifier,
  _stopProfilerIdleNotifier,
  _tickCallback,
  _disconnect,
  _handleQueue,
  _pendingMessage,
  _channel,
  _send,
  _linkedBinding
};
var process_default = _process;

// node_modules/wrangler/_virtual_unenv_global_polyfill-@cloudflare-unenv-preset-node-process
globalThis.process = process_default;

// src/index.ts
var CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Encrypted-Yw-ID, X-Is-Login"
};
function jsonResponse(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "Content-Type": "application/json",
      ...CORS_HEADERS
    }
  });
}
__name(jsonResponse, "jsonResponse");
async function getOrCreateUser(request, env2) {
  const userId = request.headers.get("X-Encrypted-Yw-ID");
  const isLogin = request.headers.get("X-Is-Login") === "1";
  if (!userId) {
    throw new Error("User ID not found");
  }
  const { results } = await env2.DB.prepare("SELECT * FROM users WHERE encrypted_yw_id = ?").bind(userId).all();
  if (results.length > 0) {
    return results[0];
  }
  const insertResult = await env2.DB.prepare(
    "INSERT INTO users (encrypted_yw_id, role) VALUES (?, ?) RETURNING *"
  ).bind(userId, "student").first();
  return insertResult;
}
__name(getOrCreateUser, "getOrCreateUser");
async function updateUserInfo(request, env2) {
  const userId = request.headers.get("X-Encrypted-Yw-ID");
  const body = await request.json();
  const { results } = await env2.DB.prepare("SELECT * FROM users WHERE encrypted_yw_id = ?").bind(userId).all();
  if (results.length === 0) {
    await env2.DB.prepare(
      "INSERT INTO users (encrypted_yw_id, display_name, photo_url, email) VALUES (?, ?, ?, ?)"
    ).bind(userId, body.display_name, body.photo_url, body.email).run();
  } else {
    await env2.DB.prepare(
      'UPDATE users SET display_name = ?, photo_url = ?, email = ?, updated_at = datetime("now") WHERE encrypted_yw_id = ?'
    ).bind(body.display_name, body.photo_url, body.email, userId).run();
  }
  return jsonResponse({ success: true });
}
__name(updateUserInfo, "updateUserInfo");
async function getCurrentUser(request, env2) {
  const user = await getOrCreateUser(request, env2);
  return jsonResponse({ user });
}
__name(getCurrentUser, "getCurrentUser");
async function updateUserClass(request, env2) {
  const userId = request.headers.get("X-Encrypted-Yw-ID");
  const body = await request.json();
  await env2.DB.prepare(
    'UPDATE users SET class = ?, updated_at = datetime("now") WHERE encrypted_yw_id = ?'
  ).bind(body.class, userId).run();
  return jsonResponse({ success: true });
}
__name(updateUserClass, "updateUserClass");
async function getSubjects(env2) {
  const { results } = await env2.DB.prepare("SELECT * FROM subjects ORDER BY name").all();
  return jsonResponse({ subjects: results });
}
__name(getSubjects, "getSubjects");
async function getNotesBySubject(subjectId, request, env2) {
  const user = await getOrCreateUser(request, env2);
  const { results } = await env2.DB.prepare(`
    SELECT 
      n.*,
      u.display_name as author_name,
      u.photo_url as author_photo
    FROM notes n
    JOIN users u ON n.author_id = u.id
    WHERE n.subject_id = ? AND (u.class = ? OR u.class IS NULL OR ? IS NULL)
    ORDER BY n.created_at DESC
  `).bind(subjectId, user.class, user.class).all();
  return jsonResponse({ notes: results });
}
__name(getNotesBySubject, "getNotesBySubject");
async function searchNotes(query, request, env2) {
  const user = await getOrCreateUser(request, env2);
  const { results } = await env2.DB.prepare(`
    SELECT 
      n.*,
      u.display_name as author_name,
      u.photo_url as author_photo,
      s.name as subject_name
    FROM notes n
    JOIN users u ON n.author_id = u.id
    JOIN subjects s ON n.subject_id = s.id
    WHERE (n.title LIKE ? OR n.description LIKE ? OR n.extracted_text LIKE ?)
      AND (u.class = ? OR u.class IS NULL OR ? IS NULL)
    ORDER BY n.created_at DESC
    LIMIT 50
  `).bind(`%${query}%`, `%${query}%`, `%${query}%`, user.class, user.class).all();
  return jsonResponse({ notes: results });
}
__name(searchNotes, "searchNotes");
async function createNote(request, env2) {
  const user = await getOrCreateUser(request, env2);
  const body = await request.json();
  const note = await env2.DB.prepare(`
    INSERT INTO notes (title, description, subject_id, author_id, extracted_text, image_path)
    VALUES (?, ?, ?, ?, ?, ?)
    RETURNING *
  `).bind(
    body.title,
    body.description,
    body.subject_id,
    user.id,
    body.extracted_text,
    body.image_path
  ).first();
  await env2.DB.batch([
    env2.DB.prepare("UPDATE users SET notes_uploaded = notes_uploaded + 1 WHERE id = ?").bind(user.id),
    env2.DB.prepare("UPDATE subjects SET note_count = note_count + 1 WHERE id = ?").bind(body.subject_id)
  ]);
  return jsonResponse({ note });
}
__name(createNote, "createNote");
async function updateNoteSummary(noteId, request, env2) {
  const body = await request.json();
  await env2.DB.prepare(
    'UPDATE notes SET summary = ?, updated_at = datetime("now") WHERE id = ?'
  ).bind(body.summary, noteId).run();
  return jsonResponse({ success: true });
}
__name(updateNoteSummary, "updateNoteSummary");
async function toggleNoteLike(noteId, request, env2) {
  const user = await getOrCreateUser(request, env2);
  const { results } = await env2.DB.prepare(
    "SELECT * FROM note_likes WHERE note_id = ? AND user_id = ?"
  ).bind(noteId, user.id).all();
  if (results.length > 0) {
    await env2.DB.batch([
      env2.DB.prepare("DELETE FROM note_likes WHERE note_id = ? AND user_id = ?").bind(noteId, user.id),
      env2.DB.prepare("UPDATE notes SET likes = likes - 1 WHERE id = ?").bind(noteId)
    ]);
    return jsonResponse({ liked: false });
  } else {
    await env2.DB.batch([
      env2.DB.prepare("INSERT INTO note_likes (note_id, user_id) VALUES (?, ?)").bind(noteId, user.id),
      env2.DB.prepare("UPDATE notes SET likes = likes + 1 WHERE id = ?").bind(noteId)
    ]);
    return jsonResponse({ liked: true });
  }
}
__name(toggleNoteLike, "toggleNoteLike");
async function getLeaderboard(env2) {
  const { results } = await env2.DB.prepare(`
    SELECT 
      encrypted_yw_id,
      display_name,
      email,
      photo_url,
      notes_uploaded,
      total_likes,
      total_admin_upvotes,
      (notes_uploaded * 10 + total_likes * 5 + total_admin_upvotes * 20) as score
    FROM users
    WHERE notes_uploaded > 0
    ORDER BY score DESC
    LIMIT 50
  `).all();
  return jsonResponse({ leaderboard: results });
}
__name(getLeaderboard, "getLeaderboard");
async function verifyAdmin(request, env2) {
  const body = await request.json();
  const { email, password } = body;
  if (email && email.endsWith("@notarium.site") && password === "51234") {
    return jsonResponse({ success: true, isAdmin: true });
  }
  return jsonResponse({ success: false, isAdmin: false, error: "Invalid credentials" }, 401);
}
__name(verifyAdmin, "verifyAdmin");
async function adminUpvoteNote(noteId, request, env2) {
  const userId = request.headers.get("X-Encrypted-Yw-ID");
  const body = await request.json();
  if (!body.isAdmin) {
    return jsonResponse({ error: "Unauthorized" }, 403);
  }
  await env2.DB.prepare(
    'UPDATE notes SET admin_upvotes = admin_upvotes + 1, updated_at = datetime("now") WHERE id = ?'
  ).bind(noteId).run();
  const note = await env2.DB.prepare("SELECT author_id FROM notes WHERE id = ?").bind(noteId).first();
  if (note) {
    await env2.DB.prepare(
      "UPDATE users SET total_admin_upvotes = total_admin_upvotes + 1 WHERE id = ?"
    ).bind(note.author_id).run();
  }
  return jsonResponse({ success: true });
}
__name(adminUpvoteNote, "adminUpvoteNote");
async function suspendUser(userId, request, env2) {
  const body = await request.json();
  if (!body.isAdmin) {
    return jsonResponse({ error: "Unauthorized" }, 403);
  }
  await env2.DB.prepare(
    'UPDATE users SET suspended = 1, updated_at = datetime("now") WHERE id = ?'
  ).bind(userId).run();
  return jsonResponse({ success: true });
}
__name(suspendUser, "suspendUser");
async function removeUser(userId, request, env2) {
  const body = await request.json();
  if (!body.isAdmin) {
    return jsonResponse({ error: "Unauthorized" }, 403);
  }
  await env2.DB.prepare("DELETE FROM users WHERE id = ?").bind(userId).run();
  return jsonResponse({ success: true });
}
__name(removeUser, "removeUser");
async function getAllUsers(request, env2) {
  const url = new URL(request.url);
  const isAdmin = url.searchParams.get("isAdmin") === "true";
  if (!isAdmin) {
    return jsonResponse({ error: "Unauthorized" }, 403);
  }
  const { results } = await env2.DB.prepare(
    "SELECT id, display_name, email, class, role, notes_uploaded, total_likes, total_admin_upvotes, suspended, created_at FROM users ORDER BY created_at DESC"
  ).all();
  return jsonResponse({ users: results });
}
__name(getAllUsers, "getAllUsers");
async function getAllNotes(request, env2) {
  const url = new URL(request.url);
  const isAdmin = url.searchParams.get("isAdmin") === "true";
  if (!isAdmin) {
    return jsonResponse({ error: "Unauthorized" }, 403);
  }
  const { results } = await env2.DB.prepare(`
    SELECT 
      n.id,
      n.title,
      n.description,
      n.likes,
      n.admin_upvotes,
      n.created_at,
      u.display_name as author_name,
      u.photo_url as author_photo,
      s.name as subject_name
    FROM notes n
    JOIN users u ON n.author_id = u.id
    JOIN subjects s ON n.subject_id = s.id
    ORDER BY n.created_at DESC
  `).all();
  return jsonResponse({ notes: results });
}
__name(getAllNotes, "getAllNotes");
async function createChatSession(request, env2) {
  const user = await getOrCreateUser(request, env2);
  const body = await request.json();
  const session = await env2.DB.prepare(`
    INSERT INTO chat_sessions (user_id, subject, topic)
    VALUES (?, ?, ?)
    RETURNING *
  `).bind(user.id, body.subject, body.topic).first();
  return jsonResponse({ session });
}
__name(createChatSession, "createChatSession");
async function getChatSessions(request, env2) {
  const user = await getOrCreateUser(request, env2);
  const { results } = await env2.DB.prepare(`
    SELECT * FROM chat_sessions
    WHERE user_id = ?
    ORDER BY updated_at DESC
    LIMIT 20
  `).bind(user.id).all();
  return jsonResponse({ sessions: results });
}
__name(getChatSessions, "getChatSessions");
async function getChatMessages(sessionId, env2) {
  const { results } = await env2.DB.prepare(`
    SELECT * FROM chat_messages
    WHERE session_id = ?
    ORDER BY created_at ASC
  `).bind(sessionId).all();
  return jsonResponse({ messages: results });
}
__name(getChatMessages, "getChatMessages");
async function addChatMessage(sessionId, request, env2) {
  const body = await request.json();
  const message = await env2.DB.prepare(`
    INSERT INTO chat_messages (session_id, role, content)
    VALUES (?, ?, ?)
    RETURNING *
  `).bind(sessionId, body.role, body.content).first();
  await env2.DB.prepare(
    'UPDATE chat_sessions SET updated_at = datetime("now") WHERE id = ?'
  ).bind(sessionId).run();
  return jsonResponse({ message });
}
__name(addChatMessage, "addChatMessage");
var src_default = {
  async fetch(request, env2) {
    if (request.method === "OPTIONS") {
      return new Response(null, { headers: CORS_HEADERS });
    }
    const url = new URL(request.url);
    const path = url.pathname;
    try {
      if (path === "/api/user/update" && request.method === "POST") {
        return await updateUserInfo(request, env2);
      }
      if (path === "/api/user/me" && request.method === "GET") {
        return await getCurrentUser(request, env2);
      }
      if (path === "/api/user/class" && request.method === "PUT") {
        return await updateUserClass(request, env2);
      }
      if (path === "/api/subjects" && request.method === "GET") {
        return await getSubjects(env2);
      }
      if (path.startsWith("/api/notes/subject/")) {
        const subjectId = path.split("/").pop();
        return await getNotesBySubject(subjectId, request, env2);
      }
      if (path === "/api/notes/search" && request.method === "GET") {
        const query = url.searchParams.get("q") || "";
        return await searchNotes(query, request, env2);
      }
      if (path === "/api/notes" && request.method === "POST") {
        return await createNote(request, env2);
      }
      if (path.match(/^\/api\/notes\/\d+\/summary$/) && request.method === "PUT") {
        const noteId = path.split("/")[3];
        return await updateNoteSummary(noteId, request, env2);
      }
      if (path.match(/^\/api\/notes\/\d+\/like$/) && request.method === "POST") {
        const noteId = path.split("/")[3];
        return await toggleNoteLike(noteId, request, env2);
      }
      if (path === "/api/leaderboard" && request.method === "GET") {
        return await getLeaderboard(env2);
      }
      if (path === "/api/chat/sessions" && request.method === "POST") {
        return await createChatSession(request, env2);
      }
      if (path === "/api/chat/sessions" && request.method === "GET") {
        return await getChatSessions(request, env2);
      }
      if (path.match(/^\/api\/chat\/sessions\/\d+\/messages$/) && request.method === "GET") {
        const sessionId = path.split("/")[4];
        return await getChatMessages(sessionId, env2);
      }
      if (path.match(/^\/api\/chat\/sessions\/\d+\/messages$/) && request.method === "POST") {
        const sessionId = path.split("/")[4];
        return await addChatMessage(sessionId, request, env2);
      }
      if (path === "/api/admin/verify" && request.method === "POST") {
        return await verifyAdmin(request, env2);
      }
      if (path.match(/^\/api\/admin\/upvote\/\d+$/) && request.method === "POST") {
        const noteId = path.split("/")[4];
        return await adminUpvoteNote(noteId, request, env2);
      }
      if (path.match(/^\/api\/admin\/suspend\/\d+$/) && request.method === "POST") {
        const userId = path.split("/")[4];
        return await suspendUser(userId, request, env2);
      }
      if (path.match(/^\/api\/admin\/user\/\d+$/) && request.method === "DELETE") {
        const userId = path.split("/")[4];
        return await removeUser(userId, request, env2);
      }
      if (path === "/api/admin/users" && request.method === "GET") {
        return await getAllUsers(request, env2);
      }
      if (path === "/api/admin/notes" && request.method === "GET") {
        return await getAllNotes(request, env2);
      }
      return jsonResponse({ error: "Not found" }, 404);
    } catch (error3) {
      console.error("API Error:", error3);
      return jsonResponse({ error: error3.message }, 500);
    }
  }
};
export {
  src_default as default
};
//# sourceMappingURL=index.js.map
