var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });

// .wrangler/tmp/bundle-AJJFv0/checked-fetch.js
var urls = /* @__PURE__ */ new Set();
function checkURL(request, init) {
  const url = request instanceof URL ? request : new URL(
    (typeof request === "string" ? new Request(request, init) : request).url
  );
  if (url.port && url.port !== "443" && url.protocol === "https:") {
    if (!urls.has(url.toString())) {
      urls.add(url.toString());
      console.warn(
        `WARNING: known issue with \`fetch()\` requests to custom HTTPS ports in published Workers:
 - ${url.toString()} - the custom port will be ignored when the Worker is published using the \`wrangler deploy\` command.
`
      );
    }
  }
}
__name(checkURL, "checkURL");
globalThis.fetch = new Proxy(globalThis.fetch, {
  apply(target, thisArg, argArray) {
    const [request, init] = argArray;
    checkURL(request, init);
    return Reflect.apply(target, thisArg, argArray);
  }
});

// src/index.ts
var src_default = {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const path = url.pathname;
    const corsHeaders = {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization"
    };
    if (request.method === "OPTIONS") {
      return new Response(null, { headers: corsHeaders });
    }
    try {
      if (path === "/" || path === "/api/health") {
        return new Response(
          JSON.stringify({
            status: "OK",
            message: "Notarium Backend Running",
            timestamp: (/* @__PURE__ */ new Date()).toISOString(),
            features: ["auth", "notes", "subjects", "gemini-ai", "leaderboard"]
          }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      if (path === "/api/auth/login" && request.method === "POST") {
        const { email, password } = await request.json();
        if (!email || !password) {
          return new Response(
            JSON.stringify({ success: false, error: "Email and password required" }),
            { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
        const mockUser = {
          id: 1,
          email,
          name: "Test User",
          display_name: email.split("@")[0],
          class: "10",
          grade: "10",
          photo_url: `https://ui-avatars.com/api/?name=${encodeURIComponent(email.split("@")[0])}&background=2e8b57&color=fff`
        };
        return new Response(
          JSON.stringify({
            success: true,
            user: mockUser,
            token: "mock-jwt-token-" + Date.now()
          }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      if (path === "/api/gemini/ocr" && request.method === "POST") {
        const { image } = await request.json();
        if (!image) {
          return new Response(
            JSON.stringify({ success: false, error: "Image data required" }),
            { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
        const mockOCRText = `EXTRACTED TEXT FROM IMAGE:

Algebra Basics

Quadratic Equations
A quadratic equation is an equation of the form:
ax\xB2 + bx + c = 0

Solutions can be found using:
x = [-b \xB1 \u221A(b\xB2 - 4ac)] / 2a

This is a mock OCR response. In production, this would call Google Gemini Vision API.`;
        return new Response(
          JSON.stringify({
            success: true,
            text: mockOCRText,
            message: "Text extracted successfully"
          }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      if (path === "/api/gemini/chat" && request.method === "POST") {
        const { message, subject, topic } = await request.json();
        if (!message) {
          return new Response(
            JSON.stringify({ success: false, error: "Message is required" }),
            { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
        const mockResponse = `I understand you're asking about ${subject || "this topic"}. 

Based on your question "${message}", here's a helpful explanation:

In ${subject || "academic subjects"}, ${topic || "this concept"} is important because it helps build foundational knowledge. 

Would you like me to explain any specific part in more detail or provide some practice questions?`;
        return new Response(
          JSON.stringify({
            success: true,
            response: mockResponse,
            message: "AI response generated"
          }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      if (path === "/api/notes" && request.method === "GET") {
        const mockNotes = [
          {
            id: 1,
            title: "Math - Algebra Basics",
            subject: "Mathematics",
            content: "Algebra is the study of variables and rules for manipulating these variables...",
            author_name: "Test User",
            likes: 5,
            admin_upvotes: 2,
            created_at: (/* @__PURE__ */ new Date()).toISOString()
          },
          {
            id: 2,
            title: "Science - Physics Introduction",
            subject: "Science",
            content: "Physics is the natural science that studies matter, its motion and behavior through space and time...",
            author_name: "Test User",
            likes: 3,
            admin_upvotes: 1,
            created_at: (/* @__PURE__ */ new Date()).toISOString()
          }
        ];
        return new Response(
          JSON.stringify({ notes: mockNotes }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      if (path === "/api/subjects" && request.method === "GET") {
        const mockSubjects = [
          { id: 1, name: "Mathematics", icon: "fa-calculator", description: "Algebra, Geometry, Calculus" },
          { id: 2, name: "Science", icon: "fa-flask", description: "Physics, Chemistry, Biology" },
          { id: 3, name: "English", icon: "fa-book", description: "Literature, Grammar, Writing" },
          { id: 4, name: "History", icon: "fa-landmark", description: "World History, Civics" },
          { id: 5, name: "Geography", icon: "fa-globe", description: "Physical and Human Geography" }
        ];
        return new Response(
          JSON.stringify({ subjects: mockSubjects }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      if (path === "/api/leaderboard" && request.method === "GET") {
        const mockLeaderboard = [
          { id: 1, display_name: "Top Student", notes_uploaded: 15, total_likes: 45, score: 75 },
          { id: 2, display_name: "Science Lover", notes_uploaded: 12, total_likes: 38, score: 62 },
          { id: 3, display_name: "Math Wizard", notes_uploaded: 10, total_likes: 42, score: 62 }
        ];
        return new Response(
          JSON.stringify({ leaderboard: mockLeaderboard }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      return new Response(
        JSON.stringify({ error: "Not found", path }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    } catch (error) {
      console.error("Server error:", error);
      return new Response(
        JSON.stringify({ error: "Internal server error" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }
  }
};

// node_modules/wrangler/templates/middleware/middleware-ensure-req-body-drained.ts
var drainBody = /* @__PURE__ */ __name(async (request, env, _ctx, middlewareCtx) => {
  try {
    return await middlewareCtx.next(request, env);
  } finally {
    try {
      if (request.body !== null && !request.bodyUsed) {
        const reader = request.body.getReader();
        while (!(await reader.read()).done) {
        }
      }
    } catch (e) {
      console.error("Failed to drain the unused request body.", e);
    }
  }
}, "drainBody");
var middleware_ensure_req_body_drained_default = drainBody;

// node_modules/wrangler/templates/middleware/middleware-miniflare3-json-error.ts
function reduceError(e) {
  return {
    name: e?.name,
    message: e?.message ?? String(e),
    stack: e?.stack,
    cause: e?.cause === void 0 ? void 0 : reduceError(e.cause)
  };
}
__name(reduceError, "reduceError");
var jsonError = /* @__PURE__ */ __name(async (request, env, _ctx, middlewareCtx) => {
  try {
    return await middlewareCtx.next(request, env);
  } catch (e) {
    const error = reduceError(e);
    return Response.json(error, {
      status: 500,
      headers: { "MF-Experimental-Error-Stack": "true" }
    });
  }
}, "jsonError");
var middleware_miniflare3_json_error_default = jsonError;

// .wrangler/tmp/bundle-AJJFv0/middleware-insertion-facade.js
var __INTERNAL_WRANGLER_MIDDLEWARE__ = [
  middleware_ensure_req_body_drained_default,
  middleware_miniflare3_json_error_default
];
var middleware_insertion_facade_default = src_default;

// node_modules/wrangler/templates/middleware/common.ts
var __facade_middleware__ = [];
function __facade_register__(...args) {
  __facade_middleware__.push(...args.flat());
}
__name(__facade_register__, "__facade_register__");
function __facade_invokeChain__(request, env, ctx, dispatch, middlewareChain) {
  const [head, ...tail] = middlewareChain;
  const middlewareCtx = {
    dispatch,
    next(newRequest, newEnv) {
      return __facade_invokeChain__(newRequest, newEnv, ctx, dispatch, tail);
    }
  };
  return head(request, env, ctx, middlewareCtx);
}
__name(__facade_invokeChain__, "__facade_invokeChain__");
function __facade_invoke__(request, env, ctx, dispatch, finalMiddleware) {
  return __facade_invokeChain__(request, env, ctx, dispatch, [
    ...__facade_middleware__,
    finalMiddleware
  ]);
}
__name(__facade_invoke__, "__facade_invoke__");

// .wrangler/tmp/bundle-AJJFv0/middleware-loader.entry.ts
var __Facade_ScheduledController__ = class ___Facade_ScheduledController__ {
  constructor(scheduledTime, cron, noRetry) {
    this.scheduledTime = scheduledTime;
    this.cron = cron;
    this.#noRetry = noRetry;
  }
  static {
    __name(this, "__Facade_ScheduledController__");
  }
  #noRetry;
  noRetry() {
    if (!(this instanceof ___Facade_ScheduledController__)) {
      throw new TypeError("Illegal invocation");
    }
    this.#noRetry();
  }
};
function wrapExportedHandler(worker) {
  if (__INTERNAL_WRANGLER_MIDDLEWARE__ === void 0 || __INTERNAL_WRANGLER_MIDDLEWARE__.length === 0) {
    return worker;
  }
  for (const middleware of __INTERNAL_WRANGLER_MIDDLEWARE__) {
    __facade_register__(middleware);
  }
  const fetchDispatcher = /* @__PURE__ */ __name(function(request, env, ctx) {
    if (worker.fetch === void 0) {
      throw new Error("Handler does not export a fetch() function.");
    }
    return worker.fetch(request, env, ctx);
  }, "fetchDispatcher");
  return {
    ...worker,
    fetch(request, env, ctx) {
      const dispatcher = /* @__PURE__ */ __name(function(type, init) {
        if (type === "scheduled" && worker.scheduled !== void 0) {
          const controller = new __Facade_ScheduledController__(
            Date.now(),
            init.cron ?? "",
            () => {
            }
          );
          return worker.scheduled(controller, env, ctx);
        }
      }, "dispatcher");
      return __facade_invoke__(request, env, ctx, dispatcher, fetchDispatcher);
    }
  };
}
__name(wrapExportedHandler, "wrapExportedHandler");
function wrapWorkerEntrypoint(klass) {
  if (__INTERNAL_WRANGLER_MIDDLEWARE__ === void 0 || __INTERNAL_WRANGLER_MIDDLEWARE__.length === 0) {
    return klass;
  }
  for (const middleware of __INTERNAL_WRANGLER_MIDDLEWARE__) {
    __facade_register__(middleware);
  }
  return class extends klass {
    #fetchDispatcher = /* @__PURE__ */ __name((request, env, ctx) => {
      this.env = env;
      this.ctx = ctx;
      if (super.fetch === void 0) {
        throw new Error("Entrypoint class does not define a fetch() function.");
      }
      return super.fetch(request);
    }, "#fetchDispatcher");
    #dispatcher = /* @__PURE__ */ __name((type, init) => {
      if (type === "scheduled" && super.scheduled !== void 0) {
        const controller = new __Facade_ScheduledController__(
          Date.now(),
          init.cron ?? "",
          () => {
          }
        );
        return super.scheduled(controller);
      }
    }, "#dispatcher");
    fetch(request) {
      return __facade_invoke__(
        request,
        this.env,
        this.ctx,
        this.#dispatcher,
        this.#fetchDispatcher
      );
    }
  };
}
__name(wrapWorkerEntrypoint, "wrapWorkerEntrypoint");
var WRAPPED_ENTRY;
if (typeof middleware_insertion_facade_default === "object") {
  WRAPPED_ENTRY = wrapExportedHandler(middleware_insertion_facade_default);
} else if (typeof middleware_insertion_facade_default === "function") {
  WRAPPED_ENTRY = wrapWorkerEntrypoint(middleware_insertion_facade_default);
}
var middleware_loader_entry_default = WRAPPED_ENTRY;
export {
  __INTERNAL_WRANGLER_MIDDLEWARE__,
  middleware_loader_entry_default as default
};
//# sourceMappingURL=index.js.map
